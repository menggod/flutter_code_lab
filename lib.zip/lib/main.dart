import 'package:flutter/material.dart';
import 'package:flutter_code_test/my_app.dart';

void main() {
  runApp(createApp());
}
